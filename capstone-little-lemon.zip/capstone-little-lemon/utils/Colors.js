const Colors = {
  primaryOne: "#495E57",
  primaryTwo: "#F3CE15",
  secondaryOne: "#EE9972",
  secondaryTwo: "#FBDABB",
  secondaryThree: "#EDEFEE",
  secondaryFour: "#333333",
  white: "#fff",
  black: "#000",
};

export default Colors;